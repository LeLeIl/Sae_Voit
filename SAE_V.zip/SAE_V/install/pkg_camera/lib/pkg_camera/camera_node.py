#!/usr/bin/env python3

import cv2
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge


class CameraBridge(Node):
    def __init__(self):
        super().__init__("camera_bridge")

        # URL streaming ESP32-CAM
        self.stream_url = "http://192.168.4.1/stream"

        # ROS 2
        self.publisher_ = self.create_publisher(Image, "/camera/image_raw", 10)

        #  OpenCV → ROS 2
        self.bridge = CvBridge()

        # ouvrir  ESP32-CAM
        self.cap = cv2.VideoCapture(self.stream_url)

        if not self.cap.isOpened():
            self.get_logger().error("❌ Non  stream  ESP32-CAM")
        else:
            self.get_logger().info("📷  stream  ESP32-CAM")

        # Timer (30 Hz aprox)
        self.timer = self.create_timer(0.033, self.timer_callback)

    def timer_callback(self):
        ret, frame = self.cap.read()
        if not ret:
            self.get_logger().warn("⚠️ pas possible de lire le  frame")
            return

        # Convertir image ROS 2
        msg = self.bridge.cv2_to_imgmsg(frame, encoding="bgr8")

        # Publier
        self.publisher_.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = CameraBridge()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()

