
#!/usr/bin/env python3
import socket
import time
import curses
import rclpy
from rclpy.node import Node

class TeleopTCP(Node):
    def __init__(self):
        super().__init__('teleop_tcp')
        # Paramètres (tu peux changer si besoin)
        self.declare_parameter('host', '192.168.4.1')
        self.declare_parameter('port', 81)
        self.host = self.get_parameter('host').value
        self.port = int(self.get_parameter('port').value)
        self.sock = None
        self.last_cmd = None
        self.last_key_time = 0.0
        self.connect()
    def connect(self):
        try:
            if self.sock:
                self.sock.close()
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.settimeout(2.0)
            self.sock.connect((self.host, self.port))
            self.sock.settimeout(None)
            self.get_logger().info(f"✅ Connecté à {self.host}:{self.port}")
        except Exception as e:
            self.sock = None
            self.get_logger().error(f"❌ Connexion impossible à {self.host}:{self.port} -> {e}")
    def send_cmd(self, c: str):
        if not self.sock:
            self.connect()
            if not self.sock:
                return
        try:
            self.sock.sendall(c.encode('utf-8'))
            self.last_cmd = c
            # log léger
            # self.get_logger().info(f"cmd={c}")
        except Exception as e:
            self.get_logger().error(f"❌ Envoi échoué ({c}) -> {e}")
            self.sock = None
    def run_curses(self, stdscr):
        stdscr.nodelay(True)
        stdscr.keypad(True)
        curses.curs_set(0)
        stdscr.addstr(0, 0, "ROS2 Teleop TCP (ESP32)\n")
        stdscr.addstr(1, 0, "Flèches: avancer/reculer/gauche/droite | Espace: STOP | Q: quitter\n")
        stdscr.addstr(3, 0, f"Target: {self.host}:{self.port}\n")
        while rclpy.ok():
            key = stdscr.getch()
            now = time.time()
            if key != -1:
                self.last_key_time = now
                if key == curses.KEY_UP:
                    self.send_cmd('F')
                    stdscr.addstr(5, 0, "Commande: F (AVANCER)   \n")
                elif key == curses.KEY_DOWN:
                    self.send_cmd('B')
                    stdscr.addstr(5, 0, "Commande: B (RECULER)    \n")
                elif key == curses.KEY_LEFT:
                    self.send_cmd('L')
                    stdscr.addstr(5, 0, "Commande: L (GAUCHE)     \n")
                elif key == curses.KEY_RIGHT:
                    self.send_cmd('R')
                    stdscr.addstr(5, 0, "Commande: R (DROITE)     \n")
                elif key == ord(' '):
                    self.send_cmd('S')
                    stdscr.addstr(5, 0, "Commande: S (STOP)       \n")
                elif key in [ord('q'), ord('Q')]:
                    self.send_cmd('S')
                    break
            # sécurité : si aucune touche depuis 0.2s => STOP
            if self.last_cmd != 'S' and (now - self.last_key_time) > 0.2:
                self.send_cmd('S')
                stdscr.addstr(5, 0, "Commande: S (STOP auto)  \n")
            stdscr.refresh()
            time.sleep(0.02)
        # fin
        try:
            if self.sock:
                self.sock.close()
        except:
            pass

def main(args=None):
    rclpy.init(args=args)
    node = TeleopTCP()
    try:
        curses.wrapper(node.run_curses)
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
